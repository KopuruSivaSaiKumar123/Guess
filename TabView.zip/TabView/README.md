
    
    // Use something below to establish communciation and get data from server
    ConnectionMgr comms("http://127.0.0.1:5000/users/1");

    comms.getData();
