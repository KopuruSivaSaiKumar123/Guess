#include "connectionMgr.h"

ConnectionMgr::ConnectionMgr(QObject *parent) : QObject(parent) {
    ConnectionMgr();
}

ConnectionMgr::~ConnectionMgr() {}
QString ConnectionMgr::ipAddress() const { return m_ipAddress; }
QString ConnectionMgr::netmask() const { return m_netmask; }
QString ConnectionMgr::gateway() const { return m_gateway; }
QString ConnectionMgr::dns() const { return m_dns; }
QString ConnectionMgr::macAddress() const { return m_macAddress; }

void ConnectionMgr::getReplyData()
{
    if (reply->error() == 0)
    {

        //QByteArray response_data = reply->readAll();
        //QJsonDocument json_doc = QJsonDocument::fromJson(response_data);

        QString response_data = (QString) reply->readAll();
        QJsonDocument json_doc = QJsonDocument::fromJson(response_data.toUtf8());

        if (!json_doc.isNull() && json_doc.isObject())
        {
            jsonObj = json_doc.object();


            qDebug() << "IP:" << jsonObj["ip_address"].toString();
            qDebug() << "MAC:" << jsonObj["mac_address"].toString();

            //qDebug() << "ID:" << jsonObj["id"].toInt();
            //qDebug() << "Name:" << jsonObj["name"].toString();


            //Emit signal here


        }
        else
        {
            qDebug() << "Invalid JSON received. - " << json_doc.isArray();

            QJsonArray jsonData = json_doc.array();
            jsonObj = jsonData[0].toObject();
            m_gateway=jsonObj["gateway"].toString();
            m_ipAddress=jsonObj["ip_address"].toString();
            m_macAddress=jsonObj["mac_address"].toString();
            qDebug() << "IP:" << jsonObj["network_name"].toString();
            m_netmask= jsonObj["subnet_mask"].toString();


            emit gatewayChanged();
            emit ipAddressChanged();
            emit macAddressChanged();
            emit netmaskChanged();


        }

    }
    else
    {
        qDebug() << "Error:" << reply->errorString();

    }

}


void ConnectionMgr::getData() 
{

    reply = manager.get(QNetworkRequest(url));

    auto r = QObject::connect(reply,&QNetworkReply::finished,this, &ConnectionMgr::getReplyData);

    qDebug() <<  "Connect -" << r;

  //  reply->deleteLater();

}




