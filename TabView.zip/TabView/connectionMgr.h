#ifndef CONNECTIONMGR_H
#define CONNECTIONMGR_H


#include <QCoreApplication>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QUrlQuery>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QString>
#include <QDebug>

class ConnectionMgr : public QObject
{
    Q_OBJECT

    Q_PROPERTY(QString ipAddress READ ipAddress NOTIFY ipAddressChanged)
    Q_PROPERTY(QString netmask READ netmask NOTIFY netmaskChanged)
    Q_PROPERTY(QString gateway READ gateway NOTIFY gatewayChanged)
    Q_PROPERTY(QString dns READ dns NOTIFY dnsChanged)
    Q_PROPERTY(QString macAddress READ macAddress NOTIFY macAddressChanged)

    public:
    explicit ConnectionMgr (QObject *parent = nullptr);
    ~ConnectionMgr ();
    Q_INVOKABLE QString ipAaddress(){
        return m_ipAddress;
    };

    QString ipAddress() const;
    QString netmask() const;
    QString gateway() const;
    QString dns() const;
    QString macAddress() const;

    QNetworkAccessManager manager;
    QNetworkReply* reply;
    QUrl url;
    QJsonObject jsonObj;


    ConnectionMgr(const QString newurl) :url(newurl) {
        m_gateway="1922.0.0.0";
    }


    // Getter for URL
    QUrl getUrl() const {
        return url;
    }

    // Setter for URL
    void setUrl(const QUrl& newUrl)
    {
        url = newUrl;

    }



    void getData(void);
    
    void updateData(void);

    signals:
    void ipAddressChanged();
    void netmaskChanged();
    void gatewayChanged();
    void dnsChanged();
    void macAddressChanged();
    void setUpdateData(QJsonObject nwData);

    public slots:
    void getReplyData();
  //  void getReplyData(QNetworkReply*);
private:
    QString m_ipAddress;
    QString m_netmask;
    QString m_gateway;
    QString m_dns;
    QString m_macAddress;


};



#endif
