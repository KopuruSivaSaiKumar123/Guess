#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include "connectionMgr.h"


int main(int argc, char *argv[])
{
    qputenv("QT_IM_MODULE", QByteArray("qtvirtualkeyboard"));

    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;
    ConnectionMgr comms("http://127.0.0.1:5000/network/setting");
    //  ConnectionMgr comms("http://127.0.0.1:5000/users/1");

    comms.getData();

    engine.rootContext()->setContextProperty("comms",&comms);

    QObject::connect(
        &engine,
        &QQmlApplicationEngine::objectCreationFailed,
        &app,
        []() { QCoreApplication::exit(-1); },
        Qt::QueuedConnection);
    engine.loadFromModule("tabview", "Main");





    return app.exec();
}
